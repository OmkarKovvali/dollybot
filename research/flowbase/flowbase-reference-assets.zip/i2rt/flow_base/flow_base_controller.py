# Modified from https://github.com/jimmyyhwu/tidybot2
import os

from i2rt.robots.robot import Robot, RobotType

os.environ["CTR_TARGET"] = "Hardware"  # pylint: disable=wrong-import-position

import atexit
import logging
import math
import os
import queue
import sys
import threading
import time
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import portal
from dm_env.specs import Array
from ruckig import ControlInterface, InputParameter, OutputParameter, Result, Ruckig
from threadpoolctl import threadpool_limits

from i2rt.flow_base import caster_steering_check
from i2rt.motor_drivers.dm_driver import ControlMode, DMChainCanInterface

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("FlowBaseController")

BASE_DEFAULT_PORT = 11323
POLICY_CONTROL_FREQ = 10
POLICY_CONTROL_PERIOD = 1.0 / POLICY_CONTROL_FREQ
# Caster positions in the base body frame (+x forward, +y left), in motor-chain order:
# index 0 = rear-left (motors 1,2), 1 = front-left (3,4), 2 = front-right (5,6), 3 = rear-right (7,8).
h_x, h_y = 0.2 * np.array([-1.0, 1.0, 1.0, -1.0]), 0.2 * np.array([1.0, 1.0, -1.0, -1.0])
# The kinematic model now uses the true physical caster layout (see h_x/h_y), so no
# body-frame mirroring is needed. AXIS_SIGN is the identity, kept as an explicit hook applied
# symmetrically to odometry (below) and command input so physical motion follows the standard
# convention (+x fwd, +y left, +z CCW) and odom equals the command.
AXIS_SIGN = np.array([1.0, 1.0, 1.0])  # (x, y, theta)
# Per-caster steering calibration, in motor-chain order (0=rear-left … 3=rear-right).
# Shared by every Vehicle/LinearRailVehicle motor chain; adjust here to recalibrate.
STEERING_OFFSET = [0.0, 0.0, 0.0, 0.0]
STEERING_DIRECTION = [-1, -1, -1, -1]


def remove_pid_file(pid_file_path: str) -> None:
    # Remove PID file if it corresponds to the current process
    if pid_file_path.exists():
        with open(pid_file_path, "r", encoding="utf-8") as f:
            pid = int(f.read().strip())
        if pid == os.getpid():
            pid_file_path.unlink()


def create_pid_file(name: str) -> None:
    # Check if PID file already exists
    pid_file_path = Path(f"/tmp/{name}.pid")
    if pid_file_path.exists():
        # Get PID of other process from lock file
        with open(pid_file_path, "r", encoding="utf-8") as f:
            pid = int(f.read().strip())

        # Check if PID matches current process
        if pid != os.getpid():
            # PID does not match current process, check if other process is still running
            try:
                os.kill(pid, 0)
            except OSError:
                print(f"Removing stale PID file (PID {pid})")
                pid_file_path.unlink()
            else:
                raise Exception(f"Another instance of the {name} is already running (PID {pid})")

    # Write PID of current process to the file
    pid_file_path.parent.mkdir(parents=True, exist_ok=True)
    with open(pid_file_path, "w", encoding="utf-8") as f:
        f.write(f"{os.getpid()}\n")

    # Register cleanup function to remove PID file upon exit
    atexit.register(remove_pid_file, pid_file_path)


# Vehicle
CONTROL_FREQ = 200  # Default control loop frequency (Hz); override per-instance via control_freq
NUM_CASTERS = 4

# Settle windows for the shutdown sequence in Vehicle.close(). The motor chain's own loop polls 8-9
# motors at ~250 Hz, so one full pass is ~4-7 ms: these are roughly ten passes and four passes.
CHAIN_FLUSH_S = 0.05
CHAIN_DRAIN_S = 0.02

# Ramp-down after a caster fault. The deadline is derived per vehicle from max(max_vel / max_accel),
# the time a full-speed axis needs to reach zero at its configured deceleration, times STOP_MARGIN --
# so it bounds a *healthy* ramp for whatever limits the caller chose, while still guaranteeing the base
# cannot keep moving if the OTG will not converge. A fixed cap could not do both: 2.0 s suits __main__'s
# max_accel of (0.8, 0.8, 3.0), but the default Vehicle max_accel of (0.25, 0.25, 0.79) needs exactly
# 2.0 s from 0.5 m/s, so the cap bit at the moment the ramp was finishing and set_neutral took the last
# sliver of speed -- the abrupt drop _brake_to_stop exists to avoid. STOP_TIMEOUT_S remains the floor.
STOP_VEL_EPS = 0.01
STOP_TIMEOUT_S = 2.0
STOP_MARGIN = 1.5

# Caster
b_x = -0.020
b_y = -0.0  # Lateral caster offset (m)
r = 0.05  # Wheel radius (m)
N_s = 1  # Steer gear ratio
N_r1 = 1  # Drive gear ratio (1st stage)
N_r2 = 1  # Drive gear ratio (2nd stage)
N_w = 1  # Wheel gear ratio
N_r1_r2_w = N_r1 * N_r2 * N_w
N_s_r2_w = N_s * N_r2 * N_w
TWO_PI = 2 * math.pi


STEER_MOTOR_IDS: Tuple[int, ...] = (1, 3, 5, 7)
"""The caster steering motors, in CAN-id order. The even ids are the drive motors, and the linear rail,
when fitted, is id 9.

Handed to the chain as ``loop_critical_motor_ids``: only these four carry feedback the swerve loop acts
on, so only these can abort a launch over a mis-scaled PMAX/VMAX. The same registers on a drive or rail
motor mis-scale translational odometry, which is reported and started anyway. See
i2rt/motor_drivers/motor_check.py for the other half of that policy, which comes from the control mode.
"""


def _warn_checks_disabled(channel: str) -> None:
    """Say what --no-verify-motor-config gives up. The chain skips both checks; this is the whole cost."""
    logger.warning(
        "motor verification is DISABLED (verify_motor_config=False) on %s. A motor that is not in speed "
        'mode will not answer, and the base will report "Motor interface is not running" as though the E '
        "stop or the wiring were at fault; a motor whose PMAX/VMAX/TMAX disagree with "
        "MotorType.get_motor_constants will silently mis-scale every reading it sends; and a motor that "
        "is not the part it is driven as -- a different gear ratio -- will not be caught either.",
        channel,
    )


class VehicleMotorController:
    def __init__(
        self,
        steering_offset: List[float],
        steering_direction: List[int],
        channel_name_or_motor_interface: str | DMChainCanInterface = "can_flow_base",
        num_casters: int = 4,
        homing_check_callback: Optional[callable] = None,
        verify_motor_config: bool = True,
    ):
        self.num_casters = num_casters
        if isinstance(channel_name_or_motor_interface, str):
            self.motor_interface = self._initialize_motor_chain(
                channel_name_or_motor_interface, steering_offset, steering_direction, verify_motor_config
            )
        else:
            self.motor_interface = channel_name_or_motor_interface

        self.motor_offsets = self.motor_interface.motor_offset
        self.motor_directions = self.motor_interface.motor_direction
        self.kd = np.array(
            [
                2,
                2,
            ]
            * self.num_casters
        )
        self.homing_check_callback = homing_check_callback  # Callback to check if homing is in progress

        print(f"dm chain can interface: {self.motor_interface} initialized")

    def _initialize_motor_chain(
        self,
        channel: str,
        steering_offset: List[float],
        steering_direction: List[int],
        verify_motor_config: bool = True,
    ) -> DMChainCanInterface:
        motor_list = []
        motor_offsets = []

        motor_directions = []
        for caster_idx in range(
            4
        ):  # chain order: 0=rear-left(1,2) 1=front-left(3,4) 2=front-right(5,6) 3=rear-right(7,8)
            motor_offsets.append(steering_offset[caster_idx])
            motor_offsets.append(0)  # drive motor no need to set offset
            motor_directions.append(steering_direction[caster_idx])
            motor_directions.append((-1) ** (caster_idx))  # drive motor direction is always 1

            caster_idx = caster_idx + 1
            steering_motor_id = caster_idx * 2 - 1
            drive_motor_id = caster_idx * 2
            motor_list.append([steering_motor_id, "DM4310V"])
            motor_list.append([drive_motor_id, "DM_FLOW_WHEEL"])

        if not verify_motor_config:
            _warn_checks_disabled(channel)

        motor_interface = DMChainCanInterface(
            motor_list,
            motor_offsets,
            motor_directions,
            channel=channel,
            motor_chain_name="holonomic_base",
            control_mode=ControlMode.VEL,
            enable_auto_recovery=False,  # fail-fast on motor error (ROB-1449); base does not self-heal
            # The base runs both checks, in that order, inside the constructor -- the last moment the bus
            # is idle. One flag drives both so --no-verify-motor-config keeps skipping everything, which
            # is what motor_drivers/utils.py's DM_FLOW_WHEEL note and flow_base/README.md document.
            check_motor_types=verify_motor_config,
            check_motor_config=verify_motor_config,
            loop_critical_motor_ids=STEER_MOTOR_IDS,
        )
        return motor_interface

    def get_state(self) -> Dict[str, Any]:
        motor_states = self.motor_interface.read_states()
        steer_pos, drive_pos = [], []
        steer_vel, drive_vel = [], []
        for idx in range(self.num_casters):
            steer_idx = idx * 2
            drive_idx = idx * 2 + 1
            steer_pos.append(motor_states[steer_idx].pos)
            drive_pos.append(motor_states[drive_idx].pos)
            steer_vel.append(motor_states[steer_idx].vel)
            drive_vel.append(motor_states[drive_idx].vel)
        result_dict = {
            "steer_pos": steer_pos,
            "drive_pos": drive_pos,
            "steer_vel": steer_vel,
            "drive_vel": drive_vel,
        }
        return result_dict

    def get_positions(self) -> List[float]:
        steer_pos, drive_pos, _, _ = self.get_state()
        return steer_pos + drive_pos

    def get_velocities(self) -> List[float]:
        _, _, steer_vel, drive_vel = self.get_state()
        return steer_vel + drive_vel

    def set_velocities(self, input_dict: Dict[str, Any]) -> None:
        steer_vel, drive_vel = input_dict["steer_vel"], input_dict["drive_vel"]
        num_motors_in_chain = len(self.motor_interface)
        num_base_motors = 2 * self.num_casters

        # Build base motor velocities (steer and drive alternating)
        vels = np.zeros(num_motors_in_chain)
        for i in range(self.num_casters):
            vels[i * 2] = steer_vel[i]  # Steer motor
            vels[i * 2 + 1] = drive_vel[i]  # Drive motor

        if num_motors_in_chain > num_base_motors:
            with self.motor_interface.command_lock:
                current_commands = self.motor_interface.commands
                if current_commands and len(current_commands) == num_motors_in_chain:
                    vels[num_base_motors:] = [cmd.vel for cmd in current_commands[num_base_motors:]]
                elif self.homing_check_callback is not None:
                    try:
                        if self.homing_check_callback():
                            logger.warning(
                                "Linear rail homing in progress but current_commands unavailable. "
                                "Linear rail velocity may be set to zero."
                            )
                    except Exception as e:
                        logger.warning(f"Error checking homing status: {e}")

        self.motor_interface.set_commands(
            torques=np.zeros(num_motors_in_chain),
            pos=np.zeros(num_motors_in_chain),
            vel=vels,
            kp=np.zeros(num_motors_in_chain),
            kd=2.0 * np.ones(num_motors_in_chain),
            get_state=False,
        )

    def set_neutral(self) -> None:
        num_motors_in_chain = len(self.motor_interface)
        self.motor_interface.set_commands(
            torques=np.zeros(num_motors_in_chain),
            pos=np.zeros(num_motors_in_chain),
            vel=np.zeros(num_motors_in_chain),
            kp=np.zeros(num_motors_in_chain),
            kd=0.5 * np.ones(num_motors_in_chain),
        )


class CommandType(Enum):
    POSITION = "position"
    VELOCITY = "velocity"


# Currently only used for velocity commands
class FrameType(Enum):
    GLOBAL = "global"
    LOCAL = "local"


class Vehicle(Robot):
    def __init__(
        self,
        max_vel: Tuple[float, float, float] = (0.5, 0.5, 1.57),
        max_accel: Tuple[float, float, float] = (0.25, 0.25, 0.79),
        channel: str | DMChainCanInterface = "can_flow_base",
        auto_start: bool = True,
        control_freq: float = CONTROL_FREQ,
        verify_motor_config: bool = True,
        check_caster_steering: bool = True,
        state_callback: Optional[Callable[[], None]] = None,
    ):
        """
        Args:
            state_callback: Called with no arguments once per control cycle, after that cycle's command is
                sent, e.g. to record state at the control rate (like MotorChainRobot's joint_state_saver).
                Runs on the control thread (SCHED_FIFO, max priority), so keep it well under 1 / control_freq
                (5 ms at 200 Hz), and keep any lock it shares with other threads briefly held: Python locks
                have no priority inheritance. No Vehicle lock is held, so it may call get_odometry(),
                get_wheel_states() and get_linear_rail_state(), but never stop_control() or close(), which
                join the control thread. With auto_start=True it starts before this constructor returns.
                Exceptions are logged (at most every 5 s) and swallowed; calls continue.
        """
        self.max_vel = np.array(max_vel)
        self.max_accel = np.array(max_accel)
        # Neither limit survives a non-positive component, and this is the only place either can be
        # checked -- both are assigned once here and never again. A zero max_accel makes the ramp-down
        # budget below inf, which silently drops one of the three bounds _brake_to_stop promises and
        # makes wait_for_stop's join timeout inf (OverflowError). A negative max_vel or max_accel is
        # rejected by Ruckig on its *first* update(), killing the control thread with an unhandled
        # RuckigError -- and a negative max_vel additionally inverts the np.clip of incoming commands,
        # which numpy resolves silently to a_max. --max-linear/--max-angular reach here from a CLI.
        if not np.all(self.max_accel > 0) or not np.all(self.max_vel > 0):
            raise ValueError(f"max_vel and max_accel must be positive on every axis, got {max_vel} and {max_accel}")
        self.control_freq = control_freq
        self.control_period = 1.0 / control_freq
        # Only a chain we opened ourselves is ours to shut down in close(); a caller who handed us a
        # live DMChainCanInterface still owns it and may keep using it afterwards. LinearRailVehicle
        # builds its own chain and passes the object down, so it re-asserts this after super().__init__.
        self._owns_motor_chain = isinstance(channel, str)
        self._closed = False

        # Use PID file to enforce single instance
        create_pid_file("base-controller")

        # Initialize hardware module
        steering_offset = STEERING_OFFSET
        steering_direction = STEERING_DIRECTION
        self.num_casters = len(steering_offset)

        self.caster_module_controller = VehicleMotorController(
            steering_offset, steering_direction, channel, verify_motor_config=verify_motor_config
        )

        # Joint space
        num_motors = 2 * NUM_CASTERS
        self.q = np.zeros(num_motors)
        self.dq = np.zeros(num_motors)

        # Operational space (global frame)
        self._lock = threading.Lock()
        self.num_dofs = 3  # (x, y, theta)
        self.x = np.zeros(self.num_dofs)
        self.dx = np.zeros(self.num_dofs)
        self.dx_local = np.zeros(self.num_dofs)

        # C matrix relating operational space velocities to joint velocities
        self.C = np.zeros((num_motors, self.num_dofs))
        self.C_steer = self.C[::2]
        self.C_drive = self.C[1::2]

        # C_p matrix relating operational space velocities to wheel velocities at the contact points
        self.C_p = np.zeros((num_motors, self.num_dofs))
        self.C_p_steer = self.C_p[::2]
        self.C_p_drive = self.C_p[1::2]
        self.C_p_steer[:, :2] = [1.0, 0.0]
        self.C_p_drive[:, :2] = [0.0, 1.0]

        # C_qp^# matrix relating joint velocities to operational space velocities
        self.C_pinv = np.zeros((num_motors, self.num_dofs))
        self.CpT_Cqinv = np.zeros((self.num_dofs, num_motors))
        self.CpT_Cqinv_steer = self.CpT_Cqinv[:, ::2]
        self.CpT_Cqinv_drive = self.CpT_Cqinv[:, 1::2]

        # OTG (online trajectory generation)
        # Note: It would be better to couple x and y using polar coordinates
        self.otg = Ruckig(self.num_dofs, self.control_period)
        self.otg_inp = InputParameter(self.num_dofs)
        self.otg_out = OutputParameter(self.num_dofs)
        self.otg_res = Result.Working
        self.otg_inp.max_velocity = self.max_vel
        self.otg_inp.max_acceleration = self.max_accel

        # Runtime steering-motor check. The fault is latched by the control thread and published to
        # the main thread only once the base has been ramped to a stop -- see caster_fault().
        self._caster_monitor = (
            caster_steering_check.CasterSteeringMonitor(h_x, h_y, b_x, self.control_period)
            if check_caster_steering
            else None
        )
        if self._caster_monitor is None:
            logger.warning(
                "runtime caster steering check is DISABLED (check_caster_steering=False). A steering "
                "motor that stalls, jams or stops accepting commands will not be noticed: the base "
                "will simply veer, and the odometry -- derived from the same feedback -- will agree "
                "with it."
            )
        self._caster_fault: Optional[caster_steering_check.CasterFault] = None
        self._caster_fault_ready = threading.Event()
        self._stop_deadline = math.inf
        # How long a healthy ramp may take at *this* caller's limits; see STOP_TIMEOUT_S.
        self._stop_budget = max(STOP_TIMEOUT_S, STOP_MARGIN * float(np.max(self.max_vel / self.max_accel)))

        self._state_callback = state_callback
        self._state_callback_logged_at = -math.inf

        # Control loop
        self.command_queue = queue.Queue(1)
        self.control_loop_thread = threading.Thread(target=self.control_loop, daemon=True)
        self.control_loop_running = False
        if auto_start:
            self.start_control()

    @staticmethod
    def _integrate_pose(x: np.ndarray, dx_local: np.ndarray, dt: float) -> Tuple[np.ndarray, np.ndarray]:
        """Midpoint-Euler integrate world pose x by body twist dx_local over dt.

        Returns (new_x, dx_world). Uses the half-step heading so the body twist is rotated
        into the world frame at the midpoint of the interval.
        """
        theta_avg = x[2] + 0.5 * dx_local[2] * dt
        R = np.array(
            [
                [math.cos(theta_avg), -math.sin(theta_avg), 0.0],
                [math.sin(theta_avg), math.cos(theta_avg), 0.0],
                [0.0, 0.0, 1.0],
            ]
        )
        dx = R @ dx_local
        return x + dx * dt, dx

    def update_state(self, dt: float | None = None) -> None:
        # Integrate against the actual elapsed loop time; fall back to the nominal period.
        if dt is None:
            dt = self.control_period
        # Joint positions and velocities
        now = time.time()
        state_dict = self.caster_module_controller.get_state()
        steer_pos, drive_pos, steer_vel, drive_vel = (
            state_dict["steer_pos"],
            state_dict["drive_pos"],
            state_dict["steer_vel"],
            state_dict["drive_vel"],
        )
        for i in range(self.num_casters):
            self.q[i * 2] = steer_pos[i]
            self.q[i * 2 + 1] = drive_pos[i]
            self.dq[i * 2] = steer_vel[i]
            self.dq[i * 2 + 1] = drive_vel[i]

        q_steer = self.q[::2]
        s = np.sin(q_steer)
        c = np.cos(q_steer)

        # C matrix
        self.C_steer[:, 0] = s / b_x
        self.C_steer[:, 1] = -c / b_x
        self.C_steer[:, 2] = (-h_x * c - h_y * s) / b_x - 1.0
        self.C_drive[:, 0] = c / r - b_y * s / (b_x * r)
        self.C_drive[:, 1] = s / r + b_y * c / (b_x * r)
        self.C_drive[:, 2] = (h_x * s - h_y * c) / r + b_y * (h_x * c + h_y * s) / (b_x * r)

        # C_p matrix
        self.C_p_steer[:, 2] = -b_x * s - b_y * c - h_y
        self.C_p_drive[:, 2] = b_x * c - b_y * s + h_x

        # C_qp^# matrix
        self.CpT_Cqinv_steer[0] = b_x * s + b_y * c
        self.CpT_Cqinv_steer[1] = -b_x * c + b_y * s
        self.CpT_Cqinv_steer[2] = b_x * (-h_x * c - h_y * s - b_x) + b_y * (h_x * s - h_y * c - b_y)
        self.CpT_Cqinv_drive[0] = r * c
        self.CpT_Cqinv_drive[1] = r * s
        self.CpT_Cqinv_drive[2] = r * (h_x * s - h_y * c - b_y)
        self.C_pinv = np.linalg.solve(self.C_p.T @ self.C_p, self.CpT_Cqinv)

        # Odometry
        with self._lock:
            dx_local = AXIS_SIGN * (self.C_pinv @ self.dq)
            self.dx_local = dx_local
            self.x, self.dx = self._integrate_pose(self.x, dx_local, dt)
        time.sleep(0.0005)

    def start_control(self) -> None:
        if self.control_loop_thread is None:
            print("To initiate a new control loop, please create a new instance of Vehicle.")
            return
        self.control_loop_running = True
        self.control_loop_thread.start()

    def stop_control(self) -> None:
        self.control_loop_running = False
        if self.control_loop_thread is not None:
            self.control_loop_thread.join()
            self.control_loop_thread = None

    def control_loop(self) -> None:
        # Set real-time scheduling policy
        try:
            os.sched_setscheduler(
                0,
                os.SCHED_FIFO,
                os.sched_param(os.sched_get_priority_max(os.SCHED_FIFO)),
            )
        except PermissionError:
            print("Failed to set real-time scheduling policy, please edit /etc/security/limits.d/99-realtime.conf")

        # Cap BLAS to one thread once, up front. Previously update_state wrapped each np.linalg.solve in
        # threadpool_limits, whose constructor rescans every loaded BLAS lib (~1 ms) on each call --
        # 16-23% of the control loop. The limit persists (threadpoolctl does not restore it on GC), so
        # setting it once here makes every solve in the loop single-threaded without the per-cycle rescan.
        # It now holds process-wide for the controller's lifetime instead of only during each solve --
        # intended: a real-time control process wants BLAS single-threaded throughout.
        threadpool_limits(limits=1, user_api="blas")

        disable_motors = True
        last_command_time = time.time()
        last_step_time = time.time()

        while self.control_loop_running:
            # Maintain the desired control frequency
            while time.time() - last_step_time < self.control_period:
                time.sleep(0.0001)
            curr_time = time.time()
            step_time = curr_time - last_step_time
            last_step_time = curr_time
            if step_time > 0.01:  # 10 ms
                logger.warning(f"Step time {1000 * step_time:.3f} ms in {self.__class__.__name__} control_loop")
                # Deliberately no hold-off for the steering check here. This is a fixed-threshold
                # *performance* warning, unrelated to control_period, and a 10-20 ms cycle is still
                # perfectly usable: dt is measured, so the check's filters and integrations stay
                # correct. The monitor applies its own dt gate for the case that actually matters --
                # a stall long enough to make dt untrustworthy. Holding off here as well disarmed the
                # check on every slow cycle, which on a loaded machine means permanently.

            # Update state (integrate odometry against the measured loop period)
            self.update_state(step_time)
            # Global to local frame conversion
            theta = self.x[2]
            R = np.array(
                [
                    [math.cos(theta), math.sin(theta), 0.0],
                    [-math.sin(theta), math.cos(theta), 0.0],
                    [0.0, 0.0, 1.0],
                ]
            )

            if self._caster_fault is not None:
                # A steering fault is latched: ignore every input and ride the OTG down to a stop.
                # The command-timeout branch below must not run here -- it forces current_velocity and
                # would hold pose instead of ramping velocity to zero.
                if self._brake_to_stop():
                    self._notify_state()  # once per update_state(), the exit cycle included
                    break
            else:
                # Check for new command
                if not self.command_queue.empty():
                    command = self.command_queue.get()
                    last_command_time = time.time()
                    target = command["target"]

                    # Velocity command
                    if command["type"] == CommandType.VELOCITY:
                        if command["frame"] == FrameType.LOCAL:
                            target = R.T @ target
                        self.otg_inp.control_interface = ControlInterface.Velocity
                        self.otg_inp.target_velocity = np.clip(target, -self.max_vel, self.max_vel)

                    # Position command
                    elif command["type"] == CommandType.POSITION:
                        self.otg_inp.control_interface = ControlInterface.Position
                        self.otg_inp.target_position = target
                        self.otg_inp.target_velocity = np.zeros_like(self.dx)

                    self.otg_res = Result.Working
                    disable_motors = False
                # Maintain current pose if command stream is disrupted
                if time.time() - last_command_time > 2.5 * POLICY_CONTROL_PERIOD:
                    self.otg_inp.target_position = self.otg_out.new_position
                    self.otg_inp.target_velocity = np.zeros_like(self.dx)
                    self.otg_inp.current_velocity = self.dx  # Set this to prevent lurch when command stream resumes
                    self.otg_res = Result.Working
                    disable_motors = True
                    if self._caster_monitor is not None:
                        self._caster_monitor.hold_off("command-stream timeout")

                # Slow down base during caster flip
                # Note: At low speeds, this section can be disabled for smoother movement
                # The threshold is the monitor's own RUNAWAY_RATE, and sharing it is not incidental:
                # this branch holds the monitor off on every cycle it fires, so the two numbers have to
                # move together or the runaway backstop silently gains or loses coverage.
                # CasterSteeringMonitor.hold_off explains why the runaway row survives that hold-off.
                if np.max(np.abs(self.dq[::2])) > caster_steering_check.RUNAWAY_RATE:  # > 720 deg/s
                    if self.otg_inp.control_interface == ControlInterface.Position:
                        self.otg_inp.target_position = self.otg_out.new_position
                    elif self.otg_inp.control_interface == ControlInterface.Velocity:
                        self.otg_inp.target_velocity = np.zeros_like(self.dx)
                    if self._caster_monitor is not None:
                        # Rewriting the OTG target mid-manoeuvre is a discontinuity in the very
                        # reference the check is judging the casters against.
                        self._caster_monitor.hold_off("caster-flip brake")

            # Update OTG
            if self.otg_res == Result.Working:
                self.otg_inp.current_position = self.x
                self.otg_res = self.otg.update(self.otg_inp, self.otg_out)
                self.otg_out.pass_to_input(self.otg_inp)

            disable_motors = False
            if disable_motors:
                # Send motor neutral commands
                self.caster_module_controller.set_neutral()

            else:
                # Operational space velocity
                dx_d = self.otg_out.new_velocity

                dx_d_local = R @ dx_d

                # Joint velocities
                dq_d = self.C @ (AXIS_SIGN * dx_d_local)

                vel_dict = {
                    "steer_vel": np.asarray(dq_d[::2], order="C"),
                    "drive_vel": np.asarray(dq_d[1:][::2], order="C"),
                }
                self.caster_module_controller.set_velocities(vel_dict)

                # Checked here and nowhere else: this is the only point where the measured joint
                # state, the commanded twist and the joint commands derived from it are all from the
                # same instant. Running it on another thread would sample them at different ones.
                if self._caster_monitor is not None and self._caster_fault is None:
                    fault = self._caster_monitor.update(AXIS_SIGN * dx_d_local, self.q[::2], dq_d[::2], self.dq[::2])
                    if fault is not None:
                        self._caster_fault = fault
                        self._stop_deadline = time.monotonic() + self._stop_budget
                        logger.error("%s", fault.render())

            # Last, so a slow callback delays the next cycle's read, not this cycle's command.
            self._notify_state()

    def _notify_state(self) -> None:
        """Run the caller's state_callback, if any, without letting it end the control loop."""
        if self._state_callback is None:
            return
        try:
            self._state_callback()
        except Exception:
            # If this thread dies the chain keeps re-sending the last wheel velocities and nothing notices. Keep
            # calling -- a failure can be transient, e.g. before the constructor returns -- and rate-limit the log.
            now = time.monotonic()
            if now - self._state_callback_logged_at >= 5.0:
                self._state_callback_logged_at = now
                logger.exception("state_callback raised; base control continues")

    def _brake_to_stop(self) -> bool:
        """Ride the OTG down to a stop after a caster fault. True once the base has stopped.

        Decelerating through the OTG at the configured ``max_accel`` rather than dropping the
        velocity command to zero: at speed the latter is a traction-limited skid stop, on a base that
        by definition already has one caster misbehaving. The three healthy casters keep steering
        correctly throughout, so the stop stays controlled.

        Bounded three ways -- the base actually stopping, ``self._stop_budget``, and the chain dying
        under us -- because a wedged OTG must not turn a fault into a base that never stops. Which of
        the three ended it is logged, because only the first is a controlled stop: the other two finish
        on ``set_neutral``, which is the abrupt drop this method exists to avoid.
        """
        self.otg_inp.control_interface = ControlInterface.Velocity
        self.otg_inp.target_velocity = np.zeros_like(self.dx)
        self.otg_res = Result.Working
        while not self.command_queue.empty():
            self.command_queue.get()  # a late remote command must not re-accelerate us
        moving = float(np.max(np.abs(self.otg_out.new_velocity))) > STOP_VEL_EPS
        if moving and time.monotonic() < self._stop_deadline and self.running():
            return False
        if not moving:
            logger.info("caster fault ramp-down complete: the base decelerated through the trajectory generator")
        elif not self.running():
            logger.error(
                "caster fault ramp-down cut short after %.2f s: the motor chain stopped running mid-ramp, so the "
                "base was still moving at %.3f and no further command can reach it.",
                self._stop_budget,
                float(np.max(np.abs(self.otg_out.new_velocity))),
            )
        else:
            logger.warning(
                "caster fault ramp-down hit its %.2f s deadline while still moving at %.3f: the trajectory "
                "generator did not converge, so the remaining speed is being taken by set_neutral rather than "
                "by a controlled deceleration.",
                self._stop_budget,
                float(np.max(np.abs(self.otg_out.new_velocity))),
            )
        self.caster_module_controller.set_neutral()
        # Publish only now: __main__ polls at 50 Hz, and seeing the fault at detection time would
        # have it tear down the chain mid-ramp, at speed.
        self._caster_fault_ready.set()
        self.control_loop_running = False
        return True

    def caster_fault(self) -> Optional[caster_steering_check.CasterFault]:
        """The latched steering fault, or None. Poll this like ``running()``.

        Non-None only once the control loop has finished ramping the base to a stop, so a caller can
        treat it as "safe to shut down now" rather than "a fault was just detected".
        """
        return self._caster_fault if self._caster_fault_ready.is_set() else None

    def wait_for_stop(self, timeout: float | None = None) -> None:
        """Block until the control loop has finished its fault ramp-down and exited.

        Defaults to this vehicle's own ramp budget plus a margin, so a caller configured with a gentle
        ``max_accel`` is not left thinking the loop hung when it is still legitimately decelerating.
        """
        if timeout is None:
            timeout = self._stop_budget + 0.5
        thread = self.control_loop_thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=timeout)

    def caster_history_csv(self) -> Optional[str]:
        """The last couple of seconds of per-caster steering data, or None if the check is off.

        Call after the base has stopped -- it walks a couple of hundred rows and has no business on
        the control thread.
        """
        return None if self._caster_monitor is None else self._caster_monitor.history_csv()

    def _enqueue_command(self, command_type: CommandType, target: Any, frame: Optional[FrameType] = None) -> None:
        if self.command_queue.full():
            print("Warning: Command queue is full. Is control loop running?")
        else:
            command = {"type": command_type, "target": target}
            if frame is not None:
                command["frame"] = FrameType(frame)
            self.command_queue.put(command, block=False)

    def get_odometry(self, input_dict: Dict[str, Any] | None = None) -> Dict[str, Any]:
        # 3-D translations: z and vz are 0.0 on the bare Vehicle; LinearRailVehicle
        # overrides this method to substitute the rail height / rate in m and m/s.
        with self._lock:
            return {
                "position": {
                    "translation": np.array([self.x[0], self.x[1], 0.0]),
                    "rotation": self.x[2],
                },
                "velocity": {
                    "world": {
                        "translation": np.array([self.dx[0], self.dx[1], 0.0]),
                        "rotation": self.dx[2],
                    },
                    "body": {
                        "translation": np.array([self.dx_local[0], self.dx_local[1], 0.0]),
                        "rotation": self.dx_local[2],
                    },
                },
            }

    def reset_odometry(self, input_dict: Dict[str, Any] | None = None) -> None:
        with self._lock:
            self.x = np.zeros(self.num_dofs)
            self.dx = np.zeros(self.num_dofs)
            self.dx_local = np.zeros(self.num_dofs)

    def get_wheel_states(self, input_dict: Dict[str, Any] | None = None) -> Dict[str, Any]:
        """Full per-motor state (pos rad, vel rad/s, eff Nm) for the 8 base motors.

        Reads the unified motor chain once and groups the 4 casters into steer/drive. The
        linear rail (9th) motor, if present, is excluded here; its state is reported by
        get_linear_rail_state.
        """
        motor_states = self.caster_module_controller.motor_interface.read_states()
        num_casters = self.caster_module_controller.num_casters
        steer = {"pos": [], "vel": [], "eff": []}
        drive = {"pos": [], "vel": [], "eff": []}
        for idx in range(num_casters):
            s = motor_states[idx * 2]
            d = motor_states[idx * 2 + 1]
            steer["pos"].append(s.pos)
            steer["vel"].append(s.vel)
            steer["eff"].append(s.eff)
            drive["pos"].append(d.pos)
            drive["vel"].append(d.vel)
            drive["eff"].append(d.eff)
        return {
            "steer": {k: np.array(v) for k, v in steer.items()},
            "drive": {k: np.array(v) for k, v in drive.items()},
        }

    def set_target_velocity(self, velocity: Any, frame: str = "local") -> None:
        self._enqueue_command(CommandType.VELOCITY, velocity, frame)

    def set_target_position(self, position: Any) -> None:
        self._enqueue_command(CommandType.POSITION, position)

    def command_target_vel(self, joint_vel: np.ndarray) -> None:
        self.set_target_velocity(joint_vel)

    def get_observations(self) -> Dict[str, np.ndarray]:
        return self.caster_module_controller.get_state()

    def get_robot_type(self) -> RobotType:
        return RobotType.MOBILE_BASE

    def joint_state_spec(self) -> Array:
        return Array(
            shape=(3,),
            dtype=np.float32,
        )

    def num_dofs(self) -> int:
        return self.num_dofs

    def running(self) -> bool:
        return self.caster_module_controller.motor_interface.running

    def close(self) -> None:
        """Stop the control loop, neutralize the motors, then release the CAN chain.

        Releasing the chain is not housekeeping -- without it this process cannot exit.
        ``DMChainCanInterface`` runs a **non-daemon** thread and nothing else in this package ever
        stops it, and CPython joins non-daemon threads *before* running ``atexit``. So the interpreter
        hangs on the way out: ``remove_pid_file`` never runs, ``/tmp/base-controller.pid`` survives,
        and ``create_pid_file`` refuses the next launch -- while the orphaned thread keeps driving the
        bus at 250 Hz, which also makes the next launch's control-mode check fail with "motor did not
        answer", pointing at the wrong component exactly as motor_check.verify_motor_config exists to prevent.

        The ordering is load-bearing: the 200 Hz control loop has to stop first or it overwrites the
        neutral command on its next iteration, and the neutral command needs time to actually reach
        the wire, because ``set_commands`` only swaps a list in memory and the chain thread is what
        sends it. A chain stopped early therefore leaves the wheels turning at the last commanded
        velocity until the motors' own ``TIMEOUT`` failsafe cuts them -- which is 8 s where it is set,
        and *never* where it is not: ``set_timeout.py`` writes ``TIMEOUT`` to 0 (disabled) unless it is
        passed ``--timeout``, so whether anything motor-side covers a mistake here is a per-station
        property nothing in this repo can promise. Read it with ``dm_motor_registers.py read TIMEOUT``.
        """
        if self._closed:
            return
        self._closed = True
        try:
            if self.control_loop_running:
                self.stop_control()
            if hasattr(self, "caster_module_controller"):
                self.caster_module_controller.set_neutral()
        except Exception as e:
            logger.error(f"Vehicle close error: {e}")
        finally:
            # In the finally: a failure to neutralize is exactly when leaving a live thread driving
            # the bus is least acceptable.
            self._release_motor_chain()
        logger.info("Vehicle closed successfully")

    def _release_motor_chain(self) -> None:
        """Let the neutral command reach the motors, then stop and close the chain we opened."""
        if not self._owns_motor_chain or not hasattr(self, "caster_module_controller"):
            return
        chain = self.caster_module_controller.motor_interface
        # Guarded step by step: a CAN failure while flushing must not skip stopping the thread.
        try:
            if chain.running:
                time.sleep(CHAIN_FLUSH_S)
        except Exception as e:
            logger.error(f"Vehicle close: flushing the neutral command failed: {e}")
        try:
            chain.running = False
            time.sleep(CHAIN_DRAIN_S)  # let the in-flight CAN round trip finish before the socket goes
        except Exception as e:
            logger.error(f"Vehicle close: stopping the motor chain failed: {e}")
        try:
            chain.close()
        except Exception as e:
            logger.error(f"Vehicle close: closing the motor chain failed: {e}")


class LinearRailVehicle(Vehicle):
    def __init__(
        self,
        vehicle_max_vel: Tuple[float, float, float] = (0.5, 0.5, 1.57),
        vehicle_max_accel: Tuple[float, float, float] = (0.25, 0.25, 0.79),
        lift_max_vel: float = 14.0,
        channel: str = "can_linear_rail",
        auto_start: bool = True,
        lift_motor_id: int = 9,
        lift_motor_type: str = "DM8009",
        auto_home: bool = True,
        homing_timeout: float = 30.0,
        enable_linear_rail: bool = True,
        control_freq: float = CONTROL_FREQ,
        total_stroke_m: float = 1.0,
        usb_gpio_device: Optional[str] = None,
        verify_motor_config: bool = True,
        check_caster_steering: bool = True,
        state_callback: Optional[Callable[[], None]] = None,
    ):
        """
        Initialize LinearRailVehicle with optional linear rail lift module.

        Args:
            vehicle_max_vel: Maximum velocity for vehicle base (x, y, theta)
            vehicle_max_accel: Maximum acceleration for vehicle base (x, y, theta)
            lift_max_vel: Linear rail homing speed in motor rad/s (applied as
                rail_speed * HOMING_SPEED_RATIO during homing); not a clip on user
                rail velocity commands.
            channel: CAN channel name for motor communication
            auto_start: Whether to automatically start the control loop
            lift_motor_id: Motor ID for the linear rail motor
            lift_motor_type: Motor type (e.g., "DM4310", "DM8009")
            auto_home: Whether to automatically home the linear rail on initialization
            homing_timeout: Timeout for homing procedure (seconds)
            enable_linear_rail: Whether to enable linear rail. If False, only base (8 motors) will be initialized.
            control_freq: Control loop frequency in Hz (drives the OTG period and CAN bandwidth check).
            total_stroke_m: Physical stroke between the rail's upper and lower limit switches,
                in meters. Used by the startup top-then-bottom calibration to derive
                meters_per_rad from the motor encoder.
            usb_gpio_device: Serial device path for the USB-GPIO converter on x86 (e.g.
                "/dev/ttyUSB0"). Ignored on a Raspberry Pi (native GPIO). When None, the
                backend keeps its default (/dev/ttyUSB0 or the I2RT_USB_GPIO_PORT env var).
            verify_motor_config: Before the motor chain claims the bus, check that every motor is in speed
                mode, repairing and persisting any that is not, and that every motor's PMAX/VMAX/TMAX
                match the constants the driver decodes their feedback with. See
                i2rt/motor_drivers/motor_check.py.
            check_caster_steering: While the base is moving, check that each steering motor is executing
                its commanded velocity, is reaching the heading the kinematics demand, and is not running
                away. On a confirmed fault the base is ramped to a stop and caster_fault() is published.
                See i2rt/flow_base/caster_steering_check.py.
            state_callback: Called by the control loop after every state update; see Vehicle.
        """
        # Take the single-instance lock before opening CAN. Vehicle.__init__ also calls this, but only
        # from super().__init__() below -- by which point this constructor has already energized every
        # motor and released the rail brake. create_pid_file is idempotent for the same PID.
        create_pid_file("base-controller")

        # Create base motor list (8 motors: 4 casters * 2 motors each)
        motor_list = []
        motor_offsets = []
        motor_directions = []

        steering_offset = STEERING_OFFSET
        steering_direction = STEERING_DIRECTION

        for caster_idx in range(
            4
        ):  # chain order: 0=rear-left(1,2) 1=front-left(3,4) 2=front-right(5,6) 3=rear-right(7,8)
            motor_offsets.append(steering_offset[caster_idx])
            motor_offsets.append(0)  # drive motor no need to set offset
            motor_directions.append(steering_direction[caster_idx])
            motor_directions.append((-1) ** (caster_idx))  # drive motor direction

            caster_idx = caster_idx + 1
            steering_motor_id = caster_idx * 2 - 1
            drive_motor_id = caster_idx * 2
            motor_list.append([steering_motor_id, "DM4310V"])
            motor_list.append([drive_motor_id, "DM_FLOW_WHEEL"])

        # Conditionally add linear rail motor (9th motor)
        if enable_linear_rail:
            motor_list.append([lift_motor_id, lift_motor_type])
            motor_offsets.append(0.0)
            motor_directions.append(1)

        if not verify_motor_config:
            _warn_checks_disabled(channel)

        # Create unified motor chain
        unified_motor_chain = DMChainCanInterface(
            motor_list=motor_list,
            motor_offset=np.array(motor_offsets),
            motor_direction=np.array(motor_directions),
            channel=channel,
            motor_chain_name="linear_rail_vehicle" if enable_linear_rail else "holonomic_base",
            control_mode=ControlMode.VEL,
            control_freq=control_freq,
            enable_auto_recovery=False,  # fail-fast on motor error (ROB-1449); base does not self-heal
            # Both checks, one flag; see _initialize_motor_chain. The rail motor (id 9) is checked too,
            # but is not loop-critical: its mis-scaled feedback moves only the height it reports.
            check_motor_types=verify_motor_config,
            check_motor_config=verify_motor_config,
            loop_critical_motor_ids=STEER_MOTOR_IDS,
            # Shorter GIL-yield than the 0.5 ms default: the base control thread writes commands every
            # cycle and must take command_lock; a tighter read-loop sleep shortens the read cycle, so the
            # waiting writer gets command_lock sooner. YAM arms keep the default. Tested 0.1 ms too; it
            # gained only ~4 Hz, so 0.2 ms was kept.
            loop_sleep_s=0.0002,
        )

        # From here to the end of __init__ the chain is live and nothing else will ever stop it: its
        # reader thread is non-daemon, DMChainCanInterface.start_thread discards the handle so it can
        # never be joined, and a constructor that raises never binds the object whose close() would
        # release it. CPython joins non-daemon threads *before* atexit, so an unguarded raise here hangs
        # the interpreter on the way out and strands /tmp/base-controller.pid -- exactly the failure
        # Vehicle.close() exists to prevent. BaseException, not Exception: Ctrl-C during rail homing is
        # the likeliest way to land here.
        try:
            # Initialize brake GPIO only if linear rail is enabled
            if enable_linear_rail:
                from i2rt.flow_base.linear_rail_controller import initialize_brake_gpio, set_usb_gpio_device

                if usb_gpio_device is not None:
                    set_usb_gpio_device(usb_gpio_device)  # no-op on Raspberry Pi
                # Raises on anything but a RuntimeError -- a SerialException when --device names the
                # wrong port on x86 is the common one.
                initialize_brake_gpio()

            # Initialize vehicle base with the unified motor chain using super().__init__()
            super().__init__(
                max_vel=vehicle_max_vel,
                max_accel=vehicle_max_accel,
                channel=unified_motor_chain,  # Pass the unified motor chain
                auto_start=auto_start,
                control_freq=control_freq,
                # Forwarded, unlike verify_motor_config: that one is deliberately not, because this
                # constructor already ran the pre-chain register check itself and the base-class path
                # would only repeat it. This check runs at runtime, so it has to be passed down.
                check_caster_steering=check_caster_steering,
                state_callback=state_callback,
            )
            # We built unified_motor_chain above, so we own it -- but Vehicle only saw a chain *object*
            # handed in, which it correctly reads as someone else's. Re-assert it, or close() leaves the
            # chain's non-daemon thread running and the process cannot exit.
            self._owns_motor_chain = True
        except BaseException:
            # No self.close() to call: super().__init__() may not have run, so caster_module_controller
            # and _closed need not exist. Stop the thread directly.
            unified_motor_chain.running = False
            unified_motor_chain.close()
            raise

        # Past super().__init__(), close() is available and is the right way to unwind: it stops the
        # control loop and neutralizes the base motors before releasing the chain. That matters here
        # because homing drives the rail, and set_timeout.py leaves the motors' TIMEOUT failsafe
        # disabled, so a chain stopped without neutralizing leaves it moving.
        try:
            # Initialize linear rail only if enabled
            self.linear_rail = None
            if enable_linear_rail:
                from i2rt.flow_base.linear_rail_controller import (
                    LinearRailController,
                    SingleMotorControlInterface,
                )

                # Create single motor control interface for the linear rail (9th motor, index 8)
                single_motor_interface = SingleMotorControlInterface.from_multi_motor_chain(
                    unified_motor_chain, target_motor_idx=8
                )

                # Initialize linear rail controller (without auto_home to initialize GPIO first)
                self.linear_rail = LinearRailController(
                    single_motor_control_interface=single_motor_interface,
                    rail_speed=lift_max_vel,
                    auto_home=False,  # Don't auto home yet, initialize GPIO first
                    homing_timeout=homing_timeout,
                    total_stroke_m=total_stroke_m,
                )

                # Initialize GPIO early, before starting homing
                self.linear_rail.initialize_gpio()

                # Now start homing if requested
                if auto_home:
                    self.linear_rail._initialize_linear_rail()

                # Set homing check callback for VehicleMotorController to prevent overwriting homing velocity
                if hasattr(self, "caster_module_controller"):
                    self.caster_module_controller.homing_check_callback = lambda: (
                        self.linear_rail.is_homing() if self.linear_rail else False
                    )
        except BaseException:
            self.close()
            raise

    def set_target_velocity(self, velocity: Any, frame: str = "local") -> None:
        """Set target velocity for both base and linear rail.

        Args:
            velocity: Target velocity. Can be:
                - 3D array [x, y, theta] for base only
                - 4D array [x, y, theta, linear_rail_vel] for base + linear rail
                  (linear_rail_vel in m/s, positive = up)
            frame: Frame for base velocity ("local" or "global")
        """
        velocity = np.asarray(velocity)

        if velocity.shape == (3,):
            # Base only
            super().set_target_velocity(velocity, frame)
        elif velocity.shape == (4,):
            # Base + linear rail
            base_velocity = velocity[:3]
            linear_rail_velocity = velocity[3]
            super().set_target_velocity(base_velocity, frame)
            if self.linear_rail is not None:
                self.set_linear_rail_velocity(linear_rail_velocity)
        else:
            raise ValueError(
                f"Velocity must be 3D [x, y, theta] or 4D [x, y, theta, linear_rail_vel], got shape {velocity.shape}"
            )

    def get_odometry(self, input_dict: Dict[str, Any] | None = None) -> Dict[str, Any]:
        """Vehicle odometry with rail height (m) substituted into the z component.

        The base only rotates about its vertical axis, so the rail's vertical motion is
        identical in the world and body frames; the same vz is written to both.
        """
        odom = super().get_odometry(input_dict)
        if self.linear_rail is not None and self.linear_rail.meters_per_rad is not None:
            rail = self.linear_rail.get_state()
            z = rail["position"]["linear"]
            vz = rail["velocity"]["linear"]
            odom["position"]["translation"][2] = z
            odom["velocity"]["world"]["translation"][2] = vz
            odom["velocity"]["body"]["translation"][2] = vz
        return odom

    def get_linear_rail_state(self, input_dict: Dict[str, Any] | None = None) -> Dict[str, Any]:
        """Get the current state of the linear rail.

        Args:
            input_dict: Optional dictionary (unused, for API compatibility)
        """
        if self.linear_rail is None:
            return {"error": "Linear rail not available"}
        state = self.linear_rail.get_state()
        motor_state = state.pop("motor_state", None)
        if motor_state is not None:
            state["eff"] = motor_state.eff  # rail motor torque (Nm)
        return state

    def set_linear_rail_velocity(self, velocity: float) -> None:
        """Set the velocity of the linear rail.

        Args:
            velocity: Target linear velocity in m/s (positive = up). Converted to motor
                rad/s using the signed calibration factor meters_per_rad, so the sign
                stays correct regardless of motor direction.
        """
        if self.linear_rail is None:
            logger.warning("Linear rail not available, ignoring velocity command")
            return
        meters_per_rad = self.linear_rail.meters_per_rad
        if meters_per_rad is None:
            logger.warning("Linear rail not calibrated (meters_per_rad is None), ignoring velocity command")
            return
        motor_velocity = velocity / meters_per_rad  # m/s / (m/rad) = rad/s
        try:
            self.linear_rail.set_velocity(motor_velocity)
        except AssertionError as e:
            logger.warning(f"Linear rail velocity command rejected: {e}")
        except Exception as e:
            logger.error(f"Failed to set linear rail velocity: {e}", exc_info=True)

    def close(self) -> None:
        """Stop the linear rail and engage its brake, then close the base.

        The rail is stopped *before* super().close() releases the chain, so its stop command still
        has a live chain thread to carry it. ``linear_rail`` is None when the rail is disabled, which
        is the default -- test the value, not just the attribute, or close() raises before the base
        motors are ever neutralized.
        """
        if getattr(self, "linear_rail", None) is not None:
            try:
                self.linear_rail.cleanup()
            except Exception as e:
                logger.error(f"Linear rail cleanup failed during close: {e}")
        super().close()


if __name__ == "__main__":
    import os
    import sys
    import time
    from dataclasses import dataclass

    import pygame
    import tyro

    from i2rt.utils.gamepad_utils import Gamepad

    @dataclass
    class Args:
        channel: str = "can0"
        """CAN channel for the base motors."""
        linear_rail: bool = False
        """Enable linear rail (9th motor). Disabled by default."""
        gamepad: bool = False
        """Enable gamepad/joystick teleop. Disabled by default (remote commands only)."""
        control_freq: float = CONTROL_FREQ
        """Control loop frequency in Hz."""
        device: Optional[str] = None
        """Serial device for the USB-GPIO converter; REQUIRED with --linear-rail on x86. Ignored on a Raspberry Pi (native GPIO)."""
        verify_motor_config: bool = True
        """Check every motor's type (gear ratio), control mode and PMAX/VMAX/TMAX before opening the chain. A wrong control mode is written and saved to Flash; a wrong gear ratio means the wrong part is fitted and always refuses; wrong scaling is only reported, and blocks the launch on a steering motor."""
        check_caster_steering: bool = True
        """While moving, check the four steering motors are executing their commands. On a fault the base ramps to a stop and this exits 2. Cannot detect a wrong steering zero or STEERING_DIRECTION -- see the flow_base README."""

    args = tyro.cli(Args)

    from i2rt.utils.usb_gpio_driver import is_raspberry_pi

    if args.linear_rail and args.device is None and not is_raspberry_pi():
        sys.exit("--device is required when --linear-rail is set on x86 (non-Raspberry Pi)")

    CALIBRATION_RETRY_DELAY = 1
    DEADZONE = 0.05  # Deadzone for base control (x, y, theta)
    RAIL_DEADZONE = 0.15  # Larger deadzone for linear rail to prevent unwanted movement

    # Initialize pygame and joystick only when gamepad teleop is enabled
    joy = None
    if args.gamepad:
        pygame.init()
        pygame.joystick.init()
        if pygame.joystick.get_count() == 0:
            print("No joystick/gamepad connected!")
            exit()
        joy = pygame.joystick.Joystick(0)

    max_vel = np.array([1.0, 1.0, np.pi])
    max_accel = np.array([0.8, 0.8, 3.0])
    lift_max_vel = 14.0  # Linear rail homing speed (motor rad/s); not a clip on user commands
    lift_max_vel_ms = 0.5  # Gamepad stick -> linear rail velocity scaling (m/s)

    # Use LinearRailVehicle instead of Vehicle
    # Pass --linear-rail to enable the 9th (lift) motor; otherwise only the 8 base motors are used.
    vehicle = LinearRailVehicle(
        vehicle_max_vel=max_vel,
        vehicle_max_accel=max_accel,
        lift_max_vel=lift_max_vel,
        channel=args.channel,
        auto_home=True,
        enable_linear_rail=args.linear_rail,  # Disabled by default, enable with --linear-rail
        control_freq=args.control_freq,
        usb_gpio_device=args.device,  # serial port for the USB-GPIO converter (x86)
        verify_motor_config=args.verify_motor_config,
        check_caster_steering=args.check_caster_steering,
    )

    # Register cleanup function to ensure brake is engaged on exit
    def close_vehicle() -> None:
        try:
            vehicle.close()
        except Exception as e:
            logger.error(f"Error during atexit close: {e}")

    atexit.register(close_vehicle)

    class TimeoutRemoteCommand:
        """Unified remote command handler for LinearRailVehicle (base + linear rail)"""

        def __init__(self, timeout: float = 0.2):
            self.timeout = timeout
            self.last_update_time = time.time() - 1000000
            self.command = np.zeros(4)  # Support 4D: [x, y, theta, linear_rail]
            self.frame = "local"
            self._lock = threading.Lock()

        def is_command_valid(self) -> bool:
            return time.time() - self.last_update_time < self.timeout

        def remote_set_target_velocity(self, input_dict: Dict[str, Any]) -> None:
            """Set target velocity for base (and optionally linear rail)"""
            target_velocity = input_dict["target_velocity"]
            frame = input_dict["frame"]
            with self._lock:
                # If 3D command, only update base part, preserve linear_rail value
                if len(target_velocity) == 3:
                    # Ensure command is 4D
                    if len(self.command) < 4:
                        self.command = np.append(self.command, 0.0) if len(self.command) == 3 else np.zeros(4)
                    # Update only base part [x, y, theta], preserve linear_rail
                    self.command[:3] = target_velocity
                else:
                    # 4D command: update everything
                    self.command = target_velocity
                self.frame = frame
                self.last_update_time = time.time()

        def get_command(self) -> Tuple[np.ndarray, str]:
            """Get base command [x, y, theta, linear_rail] and frame"""
            with self._lock:
                return self.command, self.frame

    remote_command = TimeoutRemoteCommand()

    # setup server for remote calls
    server = portal.Server(BASE_DEFAULT_PORT)
    server.bind("get_odometry", vehicle.get_odometry)
    server.bind("reset_odometry", vehicle.reset_odometry)
    server.bind("set_target_velocity", remote_command.remote_set_target_velocity)
    server.bind("get_wheel_states", vehicle.get_wheel_states)

    # Bind linear rail APIs if vehicle has linear rail
    if hasattr(vehicle, "linear_rail"):
        server.bind("get_linear_rail_state", vehicle.get_linear_rail_state)
        logger.info("Linear rail APIs bound to server")

    server.start(block=False)

    gamepad = None
    if args.gamepad:
        print(f"Joystick Name: {joy.get_name()}")
        print(f"Number of Axes: {joy.get_numaxes()}")
        print(f"Number of Buttons: {joy.get_numbuttons()}")

        # Check all x, y, th are 0 at the beginning, if not ask user to check joystick
        while True:
            # Pump events to update joystick state
            pygame.event.pump()
            four_axis = [joy.get_axis(1), joy.get_axis(0), joy.get_axis(2), joy.get_axis(3)]
            if all(np.abs(axis) < DEADZONE for axis in four_axis):
                logger.info("Joystick is at rest, please check joystick")
                break
            else:
                logger.warning(f"four_axis: {four_axis}")
                logger.warning("Joystick's rest position is not at the center, please check joystick")
                time.sleep(CALIBRATION_RETRY_DELAY)

        gamepad = Gamepad()
    else:
        logger.info("Gamepad disabled; running with remote commands only.")

    gamepad_command_frame = "local"
    gamepad_command_override = True

    last_gampad_mode_togged = False
    count = 0
    last_rail_log_time = time.time()
    RAIL_LOG_INTERVAL = 1.0  # Log linear rail position every 1 second
    try:
        while True:
            cmd_4d = np.zeros(4)
            gamepad_override_button = False
            if args.gamepad:
                gamepad_cmd = gamepad.get_user_cmd()  # 3D: [x, y, theta]
                gamepad_button = gamepad.get_button_reading()

                if gamepad_button["key_mode"] and not last_gampad_mode_togged:
                    last_gampad_mode_togged = True
                    gamepad_command_frame = "global" if gamepad_command_frame == "local" else "local"
                else:
                    last_gampad_mode_togged = False

                # Handle reset odometry (key_left_1)
                if gamepad_button["key_left_1"]:
                    vehicle.reset_odometry()

                lift_vel = 0.0
                if joy.get_numaxes() > 3:
                    right_stick_y = joy.get_axis(3)  # Right stick Y-axis
                    # Apply larger deadzone for linear rail to prevent unwanted movement
                    # Invert: up (negative axis value) = positive velocity
                    if np.abs(right_stick_y) > RAIL_DEADZONE:
                        lift_vel = -right_stick_y  # Invert: up (negative axis) = positive velocity

                cmd_4d = np.append(gamepad_cmd, lift_vel)
                gamepad_override_button = gamepad_button["key_left_2"]

            is_remote_command_valid = remote_command.is_command_valid()

            if is_remote_command_valid:
                user_cmd, user_frame = remote_command.get_command()
                gamepad_command_override = gamepad_override_button
            else:
                gamepad_command_override = True
            if not vehicle.running():
                print("Motor interface is not running, exiting...")
                print("Please check the E stop or the motor connection. ")
                break
            caster_fault = vehicle.caster_fault()
            if caster_fault is not None:
                # Non-None only after the control loop has ramped the base to a stop, so there is
                # nothing left to wind down here beyond joining that thread.
                vehicle.wait_for_stop()
                break
            if gamepad_command_override:
                # Gamepad sticks are normalized [-1, 1] -> scale to physical units
                cmd = np.append(cmd_4d[:3] * max_vel, cmd_4d[3] * lift_max_vel_ms)
                frame = gamepad_command_frame
            else:
                # Remote commands are already physical units (m/s, m/s, rad/s, rail m/s)
                cmd = user_cmd
                frame = user_frame
            if count % 20 == 0:
                # print up 1 float point
                # print(f"frame: {frame}, cmd: {cmd[0]:.1f}, {cmd[1]:.1f}, {cmd[2]:.1f}, rail: {cmd[3]:.1f}")
                sys.stdout.write(f"\rframe: {frame} cmd: {cmd[0]:.1f} {cmd[1]:.1f} {cmd[2]:.1f} rail: {cmd[3]:.1f}")
                sys.stdout.flush()

            # Log linear rail position and velocity every 1 second (only when rail is enabled)
            current_time = time.time()
            if current_time - last_rail_log_time >= RAIL_LOG_INTERVAL:
                if vehicle.linear_rail is not None:
                    try:
                        rail_state = vehicle.get_linear_rail_state()
                        position = rail_state.get("position", {})
                        velocity = rail_state.get("velocity", {})
                        pos_motor = position.get("motor")
                        pos_linear = position.get("linear")
                        vel_motor = velocity.get("motor")
                        vel_linear = velocity.get("linear")
                        motor_part = (
                            f"motor: {pos_motor:.3f} rad / {vel_motor:.3f} rad/s"
                            if pos_motor is not None and vel_motor is not None
                            else f"motor: {pos_motor} rad / {vel_motor} rad/s"
                        )
                        linear_part = (
                            f"linear: {pos_linear:.4f} m / {vel_linear:.4f} m/s"
                            if pos_linear is not None and vel_linear is not None
                            else "linear: not calibrated"
                        )
                        print(f"Linear rail - {motor_part}, {linear_part}")
                    except Exception as e:
                        print(f"Failed to get linear rail state: {e}")
                last_rail_log_time = current_time

            count += 1

            # Set target velocity: [x, y, theta, linear_rail] in physical units
            vehicle.set_target_velocity(cmd, frame=frame)

            time.sleep(0.02)
    except KeyboardInterrupt:
        print("Exiting...")
    finally:
        # Ensure close is always called, even on Ctrl+C
        try:
            vehicle.close()
        except Exception as e:
            logger.error(f"Error during close: {e}")
        if args.gamepad:
            pygame.quit()

    # After the finally: the base is stopped and the chain is closed before the operator is told why.
    caster_fault = vehicle.caster_fault()
    if caster_fault is not None:
        history_path = Path(f"/tmp/caster-fault-{os.getpid()}.csv")
        history = vehicle.caster_history_csv()
        if history is not None:
            try:
                history_path.write_text(history, encoding="utf-8")
                print(f"Wrote the last seconds of steering data to {history_path}")
            except OSError as e:
                logger.error(f"Could not write the caster fault history: {e}")
        print(caster_fault.render(), file=sys.stderr)
        sys.exit(2)
